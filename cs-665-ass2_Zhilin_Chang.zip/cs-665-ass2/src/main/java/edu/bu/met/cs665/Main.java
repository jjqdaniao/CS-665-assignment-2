/**
 * Name: Zhilin Chang
 * Course: CS-665 Software Designs & Patterns
 * Date: 2/23/2023
 * File Name: Main.java
 * Description: Unused
 */

package edu.bu.met.cs665;

public class Main {

    /**
     * A main method to run examples.
     *
     * @param args not used
     */
    public static void main(String[] args) {
        /**
         * You may use this method for development purposes as you start building your
         * assignments/final project.  This could prove convenient to test as you are developing.
         * However, please note that every assignment/final projects requires JUnit tests.
         */
        Main m = new Main();
        System.out.println("This is a test..");
    }

}
