/**
 * Name: Zhilin Chang
 * Course: CS-665 Software Designs & Patterns
 * Date: 2/23/2023
 * File Name: Notify.java
 * Description: An API to notify driver.
 */
package edu.bu.met.cs665.intereact;

public interface Notify {
    void notifyDriver();
}
